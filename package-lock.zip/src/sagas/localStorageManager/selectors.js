export const getUserState = state => state.userState;
