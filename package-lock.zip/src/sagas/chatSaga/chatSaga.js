import { all, put, call, fork, take, takeEvery,select } from 'redux-saga/effects';
//import * as actions from './actions';
import * as eventChannels from '../eventChannels/eventChannels';
//import * as chatMethods from '../../firebase/chatMethods'
//import actionTypes from '../../constants/actionTypes';
import { sendMessageFirebase } from '../../firebase/chatFirebase';
import { sendMessageStore } from '../../store/reduser/chatReduser';
import { setUserMessage } from '../../store/reduser/chatReduser';
import { setUsersMessagesStore } from '../../store/reduser/chatReduser';
import { sendMessageUser } from '../../store/reduser/chatReduser';



export function* sendMessagesSaga() {
     const  messages  = yield select(state =>state.chatState.messages)
    // const messageId = yield select(state => state.chatState.messageId)
     yield call(sendMessageFirebase,messages);
    //const { text } = yield call(sendMessageUser);
    console.log("message",messages);
    //console.log("user",user);
    //console.log("payload",payload);
//     yield call(sendMessage, {
//     message: payload.message,
//     uid: payload.uid,
//   });
 //yield put(sendMessageUser({text}));
// /  console.log(text);
}

export function* setUserMessages({ payload }) {
    if (payload.length) {
        const filteredMessagesList = payload.filter(message => message.createdAt);

        filteredMessagesList.length && (yield put(sendMessageStore(filteredMessagesList)));
    }
}

export function* startListener() {
    const chatMessagesChannel = eventChannels.chatMessagesEventChannel();

    while (true) {
        const eventAction = yield take(chatMessagesChannel);

        yield put(eventAction);
    }
}

export default function* watchChatSaga() {
    yield all([
        fork(startListener),
        takeEvery(sendMessageUser, sendMessagesSaga),
        takeEvery(setUserMessage, setUserMessages)
    ]);
};