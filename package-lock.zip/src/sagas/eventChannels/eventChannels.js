import { eventChannel } from 'redux-saga';
//import * as fb from '../../firebase/init';
//import * as actions from './actions';
//import constants from '../../firebase/constants';
import { db } from '../../firebase/Firebase';
import { setUsersMessagesStore } from '../../store/reduser/chatReduser';
import { doc,getDocs, query, collection,orderBy, onSnapshot, getFirestore } from 'firebase/firestore';
import { app } from './../../firebase/Firebase'
import { useSelector } from 'react-redux';

export function chatMessagesEventChannel() {
  
   // const {messages} = useSelector(state => state.chatState.messages)
    const listener = eventChannel(emitter => {
    const messagesRef = query(collection(db, 'messages'), orderBy('createdAt'));

    const unsubscribe = onSnapshot(messagesRef, snapshot => {
    const messages = snapshot.docs.map(doc => doc.data());
    
    emitter(setUsersMessagesStore(messages));
    });

    return unsubscribe;
  });


  
//   const dbMessage = getDocs(collection(db, "messages"));

//  let messages = []
//  dbMessage.forEach((doc) => {
//     messages.push({...doc.data(), id: doc.id})
//     });
//     return setUsersMessagesStore(messages);


 return listener;


}
