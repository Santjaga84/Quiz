import { db } from "./Firebase";
import { auth } from "./Firebase";  
import { doc,setDoc, addDoc,collection,serverTimestamp,updateDoc  } from "firebase/firestore";  
import { UserAuth } from "./authorizationMethods";    
import { select } from "redux-saga/effects";
import { useSelector } from "react-redux";

export const sendMessageFirebase = async(messages,messageId) => {
  //const user = auth.currentUser;
 
console.log("message",messages);
//console.log("user",user);    
try {

  const messagesRef = collection(db, 'messages');
  await addDoc(messagesRef, 
  {
   
    messages
    // messages: serverTimestamp(),
    //  createdAt: serverTimestamp(),
    //  displayName: messages.displayName,
    //   photoURL: messages.photoURL,
    //  message: messages
   
      
    },
    
    );
    console.log("Document written with message: ", messages);

   return { 
            message: messages,
          };
  
} catch (e) {
  console.error("Error adding document: ", e);
  throw new Error(e);
 }
}
   
