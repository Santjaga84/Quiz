import React, { useRef, useState } from 'react';
import {
    TextField,
    TextFieldButton,
    TextFieldWrapper,
    TextFieldContainer,
} from './styledComponents';
import { useSelector } from 'react-redux';
import { useDispatch } from 'react-redux';
//import { sendMessageStore } from '../../store/reduser/chatReduser';
import { useEffect } from 'react';
import { sendMessageUser } from '../../store/reduser/chatReduser';
import { UserAuth } from '../../firebase/authorizationMethods';


const CustomTextField = ({
    createdAt,
    
}) => {

//messages = useSelector(state => state.chatState.messages);

const {user} = UserAuth();
const userName = user.displayName
console.log("user",user);
console.log("user.displayName",user.displayName);

  const [value, setValue] = useState('');

  const textRef = useRef();

  const dispatch = useDispatch();

function getFormattedTimestamp() {
  const date = new Date(Date.now());// создаем новый объект Date, передавая ему значение Date.now()
  const hours = date.getHours();// получаем часы (от 0 до 23)
  const minutes = date.getMinutes();// получаем минуты (от 0 до 59)
  return `${hours.toString().padStart(2, '0')}.${minutes.toString().padStart(2, '0')}`;
// форматируем строку с помощью метода padStart()
}

  const messages = [{
      message: value,
      timestamp: getFormattedTimestamp(),
      createdAt:Date.now(), // добавляем timestamp,
      username:userName
}];

console.log(value);

  const onClickHandler = () => {
        if (value) {
            //sendMessageUser(messages);
            dispatch(sendMessageUser(messages));
            setValue('');
        }
    };

    const onChangeHandler = event => {
        const { target: { value } } = event;

        setValue(value);
    };

    const handleOnFocus = event => {
        if (event.key === 'Enter') {
            event.preventDefault();
            event.stopPropagation();

            if (value) {
                sendMessageUser(messages);
                dispatch(sendMessageUser(messages));
                setValue('');
            }
        }
    };



    return (
        <TextFieldContainer>
            <TextFieldWrapper>
                <TextField
                    ref={textRef}
                    value={value}
                    key={createdAt}
                    onChange={onChangeHandler}
                    onKeyDown={handleOnFocus}
                    placeholder={'Send a message...'}
                />
            </TextFieldWrapper>
            <TextFieldButton
                onClick={onClickHandler}
                children={'SEND'}
            />
        </TextFieldContainer>
    );
};

export default CustomTextField;
