export const MAIN_ROUTE = '/main';
export const LOGIN_ROUTE = '/';
