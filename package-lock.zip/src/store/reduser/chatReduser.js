import { createSlice } from "@reduxjs/toolkit";


// function getFormattedTimestamp() {
//   const date = new Date(Date.now());// создаем новый объект Date, передавая ему значение Date.now()
//   const hours = date.getHours();// получаем часы (от 0 до 23)
//   const minutes = date.getMinutes();// получаем минуты (от 0 до 59)
//   return `${hours.toString().padStart(2, '0')}.${minutes.toString().padStart(2, '0')}`;
// // форматируем строку с помощью метода padStart()
// }




const chatSlice = createSlice({
  name: 'chat',
  initialState: {
  messages: [],
  },
  reducers: {
 
  setUsersMessagesStore: (state, action) => {
     
    state.messages = action.payload;
    },
  
  sendMessageUser:(state, action) => {
    
    state.messages = [...state.messages, ...action.payload];
   
      console.log(action);
   
    },  
  sendMessageStore:(state,action) => {
     // state.messages.push(action.payload);
     
     const newMessage = {
        messages: action.payload,
        timestamp: Date.now()
         // добавляем timestamp
      };
      state.messages.push(newMessage);
    },
    
  setUserMessage:(state,action) => {
      state.sendMessage = action.payload.sendMessage
    }
  }
  });

  export const {
  setUsersMessagesStore,
  sendMessageStore,
  setUserMessage,
  sendMessageUser
} = chatSlice.actions;

export default chatSlice.reducer;
