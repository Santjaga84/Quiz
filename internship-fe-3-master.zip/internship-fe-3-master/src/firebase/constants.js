export default {
    USERS: 'users',
    MESSAGES: 'messages',
    QUESTIONS: 'questions',
    USERS_RESULTS: 'usersResults',
    USERS_READINESS: 'usersReadiness',
};
