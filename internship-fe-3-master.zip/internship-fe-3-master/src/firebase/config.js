const config = {
    apiKey: "AIzaSyC06GUcdxnsyMpb--BK4n596ABph3kMGTY",
    authDomain: "quiz-chat-user.firebaseapp.com",
    projectId: "quiz-chat-user",
    storageBucket: "quiz-chat-user.appspot.com",
    messagingSenderId: "264866694873",
    appId: "1:264866694873:web:f8909c5c86466245caa0c8",
    measurementId: "G-ZHQV6BYQZW"
};

export default config;
