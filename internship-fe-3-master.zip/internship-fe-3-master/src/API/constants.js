export const questionsUrl = 'https://opentdb.com/api.php?amount=10&difficulty=hard';
