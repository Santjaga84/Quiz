export default {
    color__01: '#2c2d32',//main
    color__02: '#232327',//main dark
    color__03: 'white',//white
    color__04: 'yellow',//border login button
    color__05: '#56bab7',//brand
    color__06: 'antiquewhite',//textfield color
    color__07: '#696969a8',//textfield bg color
    color__08: 'linear-gradient(4deg,#00000057,transparent)',//massageBox gradient color
    color__09: 'rgba(0,0,0,0.75) 0px 5px 15px',//massageBox boxShadow
    color__10: 'red',//wrong answer
    color__11: 'rgb(17, 29, 56) 0 3px 6px, rgba(0, 0, 0, 0.69) 0 3px 6px',//game window boxShadow
};
