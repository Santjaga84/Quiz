import Component from './Main';

export default Component;
