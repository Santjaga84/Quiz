import actionTypes from '../../constants/actionTypes';

export const signOut = () => ({ type: actionTypes.SIGN_OUT });
