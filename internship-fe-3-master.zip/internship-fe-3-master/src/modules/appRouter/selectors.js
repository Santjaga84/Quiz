export const getUserId = state => state.userState.userId;
