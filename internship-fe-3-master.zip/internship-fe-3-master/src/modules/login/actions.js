import actionTypes from '../../constants/actionTypes';

export const signInWithGoogle = () => ({ type: actionTypes.SIGN_IN_WITH_GOOGLE });
