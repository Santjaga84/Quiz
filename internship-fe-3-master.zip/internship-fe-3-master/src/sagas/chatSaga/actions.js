import actionTypes from '../../constants/actionTypes';

export const setUsersMessagesStore = payload => ({ type: actionTypes.SET_USERS_MESSAGES_STORE, payload });
