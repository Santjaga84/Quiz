export const getDocId = state => state.userState.userDocId;
export const getUserId = state => state.userState.userId;
export const getUserReadinessDocId = state => state.quizState.currentUserReadiness[0]?.userReadinessDocId;
